package com.resuadam2.listacompraexamen.ui.navigation

enum class AppScreens {
    HOME,
    LISTA_COMPRA,
    DETALLE_COMPRA
}