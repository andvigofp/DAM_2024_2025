Woof App
==================================

The Woof app is a list of dog photos with information about them including their name, age, and favorite activity. This app also uses Material Design to create a beautiful app experience for the user.

Introduction
------------

This is the solution code for the Material Theming with Jetpack Compose Codelab. This project is an opportunity for you to learn Material3 and reinforce the concepts you've learned so far in Android Basics with Compose.

Pre-requisites
--------------

- Rows/Columns
- Modifiers
- Scaffold
- Adding images
- Button click handlers
- Functions
- Classes
- Lists
- App architecture

Getting Started
---------------

1. Download the project
2. Open the project in Android Studio
3. Run the project
