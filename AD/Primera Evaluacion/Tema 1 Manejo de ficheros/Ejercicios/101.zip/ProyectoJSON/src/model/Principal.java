package model;

public class Principal
{

    public static void main(String[] args)
    {
        AplicacionAutores app = new AplicacionAutores();
        app.ejecutar();
    }
}