import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador implements ActionListener{

	// TODO: CONSTRUCTOR DEL CONTROLADOR CON LA VISTA Y EL MODELO
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//TODO: USAR e.getActionCommand() PARA SABER QUE SE EST� EJECUTANDO
        //TODO: OBTENER PAR�METROS DE LA VISTA, OBTENER INFORMACI�N DE LOS ALUMNOS Y ACTUALIZAR VALOR DE LA TABLA
	}
}
