package ejercicio305;

public class main {
    
    public static void main(String[] args) {
        
        // TODO: INSTANCIAR EL MODELO, LA VISTA Y EL CONTROLADOR
        // TODO: ARRANCHAR LA VISTA Y ESTABLECERLE EL CONTROLADOR
        
    }
}
