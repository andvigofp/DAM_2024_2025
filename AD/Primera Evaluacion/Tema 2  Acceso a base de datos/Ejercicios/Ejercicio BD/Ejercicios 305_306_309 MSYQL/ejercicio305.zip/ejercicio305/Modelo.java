package ejercicio305;

public class Modelo {
    
    // TODO: DEFINICIÓN DE LA FUNCIÓN DE SUMA
    
}
