package ejercicio306;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador implements ActionListener{
    
    // TODO: CONSTRUCTOR DEL CONTROLADOR CON LA VISTA Y EL MODELO
    
    @Override
    public void actionPerformed(ActionEvent e) {
        //TODO: USAR e.getActionCommand() PARA SABER QUE SE ESTÁ EJECUTANDO
        //TODO: OBTENER PARÁMETROS DE LA VISTA, OBTENER INFORMACIÓN USUARIO Y PINTAR EL VALOR EN LA VISTA
    } 
}
