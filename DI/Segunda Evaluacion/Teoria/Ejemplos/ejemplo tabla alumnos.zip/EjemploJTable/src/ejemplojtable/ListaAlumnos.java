/**
 * Esta clase tiene todos los métodos relacionados con el ArrayList de alumnos y sus
 * diferentes funciones de agregar, borrar, buscar, modificar, limpiar tabla, rellenar las
 * dos tablas, junto con sus atributos y el constructor vacío.
 */
package ejemplojtable;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;


public class ListaAlumnos {

    //Atributos.
    public static ArrayList<Alumno> alumnos = new ArrayList<>();
    private Alumno aux;


    //Constructor vacío.
    public ListaAlumnos() {

    }
    
    public static ArrayList<Alumno> getAlumnos() {
        return alumnos;
    }

    //rellenar array auto
    
    public void cargarA(ArrayList als){

        for(int i=0;i<10;i++){
            Alumno a= new Alumno(i, ("nombre"+i), ("dni"+i), ("tlfno"+i));
            als.add(a);
            
        }
        System.err.println("ARRAY LLENO.");
    }
    public void nuevo(Alumno aux){
        alumnos.add(aux);
    }
    public void listar(){
        for(int i=0;i<alumnos.size();i++){
            System.out.println(alumnos.get(i).toString());
        }
    }
    public int tamano(){
        return alumnos.size();
    }
    public Alumno verA(int i){
        return alumnos.get(i);
    }

}
