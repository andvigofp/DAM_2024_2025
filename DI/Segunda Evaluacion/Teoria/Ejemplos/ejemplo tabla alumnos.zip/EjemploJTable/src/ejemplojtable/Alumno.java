
package ejemplojtable;

public class Alumno {

    //Atributos.
    private int idAlumno;
    private String nombre;
    private String dni;
    private String telefono;

    private static int contAlumnos;

    //Constructor vacío.
    public Alumno() {
        this.idAlumno = ++contAlumnos;  //Para que sea el id autoincrementable.
    }

    //Constructor con los parámetros para inicializarlos.
    public Alumno(int idAlumno, String nombre, String dni, String telefono) {
        this.idAlumno = idAlumno;
        this.nombre = nombre;
        this.dni = dni;
        this.telefono = telefono;
    }

    //Getters y Setters.
    public int getIdAlumno() {
        return idAlumno;
    }
    
    public void setIdAlumno(int idAlumno) {
        this.idAlumno = idAlumno;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }
    
    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    //Método toString().
    @Override
    public String toString() {
        return "Id Alumno " + idAlumno + "\nNombre: " + nombre + "\nDNI: " + dni + "\nTelefono: " + telefono+"\n\n";
    }
    
    //Método para poder insertar los datos en el fichero usando el separador ",".
    public String insertarFilas() {
        return idAlumno + "]" + nombre + "]" + dni + "]" + telefono + "]";
    }
}
