/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplojtable;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author David ejemplo de la creación e inserción de elementos en la tabla
 */
public class EjercicioTablaAlumnos extends JFrame {

    JLabel text = new JLabel("TABLA");
    static JLabel valor = new JLabel("Info.");

    public EjercicioTablaAlumnos() {

        super("Tabla añadiendo objetos de tipo Alumno");

        DefaultTableModel dtm = new DefaultTableModel();

        dtm.addColumn("ID");
        dtm.addColumn("nombre");
        dtm.addColumn("DNI");
        dtm.addColumn("Tlfono");
        
        //Otra opcion
       // dtm.setColumnIdentifiers(new Object[]{"ID","nombre","dni","tlfono"});

        String[] s1 = {"1", "Ana", "36111111", "986111111"};
        String[] s2 = {"2", "Bea", "36111111", "986222222"};
        String[] s3 = {"3", "Carlos", "36111111", "986333333"};
        String[] s4 = {"4", "Daniel", "36111111", "986444444"};
        //rellenamos la tabla con valores
        dtm.addRow(s1);
        dtm.addRow(s2);
        dtm.addRow(s3);
        dtm.addRow(s4);
        dtm.addRow(s1);
        dtm.addRow(s2);
        dtm.addRow(s3);
        dtm.addRow(s4);
        dtm.addRow(s1);
        dtm.addRow(s2);
        dtm.addRow(s3);
        dtm.addRow(s4);
        dtm.addRow(s1);
        dtm.addRow(s2);
        dtm.addRow(s3);
        dtm.addRow(s4);
        dtm.addRow(s1);
        dtm.addRow(s2);
        dtm.addRow(s3);
        dtm.addRow(s4);
        dtm.addRow(s1);
        dtm.addRow(s2);
        dtm.addRow(s3);
        dtm.addRow(s4);

        JTable t = new JTable(dtm);

//podemos añadirle una barra de desplazamiento
        JScrollPane scroll = new JScrollPane(t);
        //        scroll.setSize(400,400);

//agregamos el scroll al frame, al estar contenida en el la tabla,
        text.setBounds(200, 10, 50, 20);
        scroll.setBounds(20, 50, 400, 400);
        valor.setBounds(150, 25, 120, 25);
        add(text);
        add(valor);
        add(scroll);
        cargarA(dtm);

        valor.setText("(hay " + dtm.getRowCount()+ " alumnos.)");

        //metodos del frame
        setLayout(null);
        setBounds(20, 20, 460, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setLocationRelativeTo(null);

    }

    public void cargarA(DefaultTableModel d) {
//rellena la tabla con 10 alumnos
        for (int i = 0; i < 10; i++) {
            Alumno a = new Alumno(i, ("nombre" + i), ("dni" + i), ("tlfno" + i));
            String[] id = {String.valueOf(a.getIdAlumno()), a.getNombre(), a.getDni(), a.getTelefono()};
            d.addRow(id);
        }

    }

    public static void main(String[] args) {
        EjercicioTablaAlumnos ejt = new EjercicioTablaAlumnos();
        ListaAlumnos l = new ListaAlumnos();
        l.cargarA(l.alumnos);
        l.listar();
        
        //otro ejemplo:
        TablaArrayList tl= new TablaArrayList(l);
        tl.mostrar();

    }

}
