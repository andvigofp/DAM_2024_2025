/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplojtable;

import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author David Otro ejemplo
 */
public class TablaArrayList extends JFrame {

    DefaultTableModel modelo = new DefaultTableModel();
    JScrollPane scroll;
    JTable tabla;

    public TablaArrayList() {
        super("tabla vacia");

        //elementos para la tabla

        tabla = new JTable(modelo);
        scroll = new JScrollPane(tabla);
        scroll.setBounds(50, 50, 400, 300);
        add(scroll);

        setLayout(null);
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void mostrar() {
        ListaAlumnos la = new ListaAlumnos();
// creación del arrayList de alumnos
        ArrayList<Alumno> listado = ListaAlumnos.alumnos;

        //
        for (int i = 0; i < listado.size(); i++) {

            String[] id = {String.valueOf(listado.get(i).getIdAlumno()), listado.get(i).getNombre(), listado.get(i).getDni(), listado.get(i).getTelefono()};
            modelo.addRow(id);
            System.err.println(listado.get(i).getIdAlumno());

        }
    }

    public TablaArrayList(ListaAlumnos lista) {
        super("Mi tabla de arraylist de objetos de la clase Alumno");

        //titulos de las comlumnas para la tabla
        modelo.addColumn("ID");
        modelo.addColumn("nombre");
        modelo.addColumn("DNI");
        modelo.addColumn("Tlfono");

        //podemos crear nuevos alumnos y añadirlos a nuestro arraylist
        Alumno a1 = new Alumno(1, "Ana", "36111111", "981111111");
        Alumno a2 = new Alumno(2, "Bea", "36111111", "981111111");
        Alumno a3 = new Alumno(3, "CArlos", "36111111", "981111111");
        Alumno a4 = new Alumno(4, "Daniel", "36111111", "981111111");
        lista.nuevo(a1);
        lista.nuevo(a2);
        lista.nuevo(a3);
        lista.nuevo(a4);

        //creación de la tabla
        tabla = new JTable(modelo);
        scroll = new JScrollPane(tabla);

        for (int i = 0; i < lista.tamano(); i++) {
            Alumno elemento = lista.verA(i);
            modelo.addRow(new Object[]{elemento.getIdAlumno(), elemento.getNombre(), elemento.getDni(), elemento.getTelefono()});
            System.err.print(i + " -");
        }

        scroll.setBounds(10, 10, 400, 300);
        add(scroll);
        
        //metodos del frame
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

    }
    public static void main(String[] args) {
        ListaAlumnos l= new ListaAlumnos();
        TablaArrayList ta= new TablaArrayList(l);
        ta.mostrar();
    }

}
