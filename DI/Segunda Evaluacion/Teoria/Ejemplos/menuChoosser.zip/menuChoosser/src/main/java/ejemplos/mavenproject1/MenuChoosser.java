/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ejemplos.mavenproject1;

import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import vista.Frameppal;

/**
 *
 * @author david
 */
public class MenuChoosser {
    JFileChooser jfc;
    JColorChooser jcc;
    public static void main(String[] args) {
        System.out.println("hola World!");
        Frameppal fp= new Frameppal();
        fp.setVisible(true);
        
    }
    
}
