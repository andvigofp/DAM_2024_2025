/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objeto;

/**
 *
 * @author david
 */
public class Persona {

    @Override
    public String toString() {
        return "Persona:" + "dni= " + dni + ", Nombre= " + nombrePersona + '.';
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public void setNombrePersona(String nombrePersona) {
        this.nombrePersona = nombrePersona;
    }

    public String getDni() {
        return dni;
    }

    public String getNombrePersona() {
        return nombrePersona;
    }

    public Persona(String dni, String nombrePersona) {
        this.dni = dni;
        this.nombrePersona = nombrePersona;
    }
 private String dni;
 private String nombrePersona;
}
    