/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.util.ArrayList;
import objeto.Persona;

/**
 *
 * @author david
 */
public class EjemploComboPersona {

    public ArrayList <Persona> listadoPersonas;
    
    public EjemploComboPersona() {
    }
    public void crearArray(){
        listadoPersonas= new ArrayList();
        
}
    public void insertarPersona(Persona p){
        listadoPersonas.add(p);
        
    }
    public String listaPersona(){
        String p="";
        for(int cont=0; cont<listadoPersonas.size();cont++){
            p+=listadoPersonas.get(cont).toString()+ "\n";
            
        }
        
        return p;
    }
    public boolean modificaPersona(Persona p){
        boolean encontrado=false;
           for(int cont=0; cont<listadoPersonas.size();cont++){
               if(listadoPersonas.get(cont).getDni().equals(p.getDni())){
                   encontrado= true;
                   listadoPersonas.get(cont).setNombrePersona(p.getNombrePersona());
               };
        }
           return encontrado;
    }
    public boolean eliminaPersona(String dni){
         boolean encontrado=false;
           for(int cont=0; cont<listadoPersonas.size();cont++){
               if(listadoPersonas.get(cont).getDni().equals(dni)){
                   encontrado= true;
                   listadoPersonas.remove(cont);
               };
        }
           return encontrado;       
    }
}
