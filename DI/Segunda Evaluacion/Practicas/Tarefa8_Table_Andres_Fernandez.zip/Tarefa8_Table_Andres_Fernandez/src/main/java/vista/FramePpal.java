/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import controlador.MuebleControlador;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import objeto.Mueble;

/**
 *
 * @author Andrés Fernández Pereira
 */
public class FramePpal extends javax.swing.JFrame {
        private MuebleControlador controlador;
        private DefaultTableModel modeloTabla;

    /**
     * Creates new form FramePpal
     */
    public FramePpal() {
        initComponents();
        controlador = new MuebleControlador();
        
        modeloTabla = new DefaultTableModel(new Object[]{"Nombre", "Color", "Material", "Ancho", "Alto", "Fondo"}, 0);
        jTMoblesDisponibles.setModel(modeloTabla);
        
        // Desactivar botones inicialmente
        jElimnarMoble.setEnabled(false);
        jElimnarTodas.setEnabled(false);
        jInforme.setEnabled(false);

        // Configurar el mensaje cuando no hay muebles disponibles
        mensaje.setVisible(true); // Inicialmente visible
        
        configuarEvenetos();
    }
    
    
    private void configuarEvenetos() {
        jEngadir.addActionListener(e -> agregarMueble());
        jElimnarMoble.addActionListener(e -> eliminarMueble());
        jElimnarTodas.addActionListener(e -> eliminarTodosLosMuebles());
        jInforme.addActionListener(e -> mostrarMueble());
    }

    
    // Métodos de acción para los botones
    private void agregarMueble() {
        String nombre = jTnome.getText();
        String color = jTCor.getText();
        String material = (String) jComboBox1.getSelectedItem();
        int ancho = Integer.parseInt(jTAncho.getText());
        int alto = Integer.parseInt(jTAlto.getText());
        int fondo = Integer.parseInt(jTFondo.getText());

        // Crear un nuevo objeto Mueble
        Mueble mueble = new Mueble(nombre, color, material, ancho, alto, fondo);

        // Agregar el mueble a la lista (o modelo de datos)
        controlador.agregarMueble(mueble);

        modeloTabla.addRow(new Object[]{mueble.getNombre(), mueble.getColor(), mueble.getMaterial(), mueble.getAncho(), mueble.getAlto(), mueble.getFondo()});

        // Habilitar botones después de agregar un mueble
        jElimnarMoble.setEnabled(true);
        jElimnarTodas.setEnabled(true);
        jInforme.setEnabled(true);

        // Ocultar mensaje cuando hay muebles disponibles
        mensaje.setVisible(false);

        // Limpiar los campos de texto después de agregar el mueble
        limpiarCampos();
    }
    
    private void limpiarCampos() {
        jTnome.setText("");
        jTCor.setText("");
        jTAncho.setText("");
        jTAlto.setText("");
        jTFondo.setText("");
    }
    
    private void eliminarMueble() {
        int selectedRow = jTMoblesDisponibles.getSelectedRow();
        if (selectedRow != -1) {
            modeloTabla.removeRow(selectedRow);
            controlador.eliminarMueble(selectedRow);
            JOptionPane.showMessageDialog(this, "Elimando de la lista correctamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona un mueble para eliminar");
        }
    }
    
    private void eliminarTodosLosMuebles() {
        modeloTabla.setRowCount(0);
        controlador.eliminarTodosLosMuebles();
    }
    
    
     private void mostrarMueble() {
        int selectedRow = jTMoblesDisponibles.getSelectedRow();
        if (selectedRow != -1) {
            Mueble mueble = controlador.obtenerMueble(selectedRow);
            String detalles = String.format("Nombre: %s\nColor: %s\nMaterial: %s\nAncho: %d\nAlto: %d\nFondo: %d",
                    mueble.getNombre(), mueble.getColor(), mueble.getMaterial(), mueble.getAncho(), mueble.getAlto(), mueble.getFondo());
            JOptionPane.showMessageDialog(this, detalles);
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona un mueble para mostrar");
        }
    }
     
     
     // Getters para los componentes
    public JTextField getJTnome() {
        return jTnome;
    }

    public JTextField getJTCor() {
        return jTCor;
    }

    public JComboBox<String> getJComboBox1() {
        return jComboBox1;
    }

    public JTextField getJTAncho() {
        return jTAncho;
    }

    public JTextField getJTAlto() {
        return jTAlto;
    }

    public JTextField getJTFondo() {
        return jTFondo;
    }

    public JButton getBtnAgregar() {
        return jEngadir;
    }

    public JButton getBtnEliminar() {
        return jElimnarMoble;
    }

    public JButton getBtnEliminarTodas() {
        return jElimnarTodas;
    }

    public JButton getMostrar() {
        return jInforme;
    }

    public JTable getJTMoblesDisponibles() {
        return jTMoblesDisponibles;
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLNome = new javax.swing.JLabel();
        jTnome = new javax.swing.JTextField();
        jEngadir = new javax.swing.JButton();
        jLCor = new javax.swing.JLabel();
        jTCor = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLAncho = new javax.swing.JLabel();
        jTAncho = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLAlto = new javax.swing.JLabel();
        jTAlto = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLFondo = new javax.swing.JLabel();
        jTFondo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTMoblesDisponibles = new javax.swing.JTable();
        jInforme = new javax.swing.JButton();
        jElimnarMoble = new javax.swing.JButton();
        jElimnarTodas = new javax.swing.JButton();
        mensaje = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Novo moble");

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setForeground(new java.awt.Color(204, 204, 204));

        jLNome.setText("Nome");

        jEngadir.setText("Engadir");

        jLCor.setText("Cor");

        jLabel2.setText("Material");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Carballo", "Ferro", "Plástico", "Piñeiro" }));

        jLAncho.setText("Ancho");

        jLabel3.setText("(cm)");

        jLAlto.setText("Alto");

        jLabel4.setText("(cm)");

        jLFondo.setText("Fondo");

        jLabel5.setText("(cm)");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLCor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLNome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jTCor, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox1, 0, 316, Short.MAX_VALUE))
                            .addComponent(jTnome))
                        .addGap(18, 18, 18)
                        .addComponent(jEngadir, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLAncho)
                        .addGap(18, 18, 18)
                        .addComponent(jTAncho, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jLAlto)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTAlto, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLFondo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFondo, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLNome)
                    .addComponent(jTnome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jEngadir))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLCor)
                    .addComponent(jTCor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLAncho)
                    .addComponent(jTAncho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLAlto)
                    .addComponent(jTAlto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLFondo)
                    .addComponent(jTFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Mobles Disponibles");

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTMoblesDisponibles.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "NOME", "COR", "MATERIAL", "MEDIDAS (AN*A*AF*)"
            }
        ));
        jTMoblesDisponibles.setToolTipText("");
        jTMoblesDisponibles.setEnabled(false);
        jScrollPane2.setViewportView(jTMoblesDisponibles);

        jInforme.setText("Informe dos  mobles");

        jElimnarMoble.setText("Elimnar Moble");

        jElimnarTodas.setText("Eliminar Todas");

        mensaje.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        mensaje.setText("NO HAY MUBELES DISPONIBLES");
        mensaje.setInheritsPopupMenu(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(237, 237, 237)
                        .addComponent(mensaje, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jInforme, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jElimnarMoble, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jElimnarTodas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mensaje, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jInforme)
                    .addComponent(jElimnarMoble)
                    .addComponent(jElimnarTodas))
                .addContainerGap(69, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel6))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FramePpal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FramePpal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FramePpal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FramePpal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FramePpal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JButton jElimnarMoble;
    private javax.swing.JButton jElimnarTodas;
    private javax.swing.JButton jEngadir;
    private javax.swing.JButton jInforme;
    private javax.swing.JLabel jLAlto;
    private javax.swing.JLabel jLAncho;
    private javax.swing.JLabel jLCor;
    private javax.swing.JLabel jLFondo;
    private javax.swing.JLabel jLNome;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTAlto;
    private javax.swing.JTextField jTAncho;
    private javax.swing.JTextField jTCor;
    private javax.swing.JTextField jTFondo;
    private javax.swing.JTable jTMoblesDisponibles;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTnome;
    private javax.swing.JLabel mensaje;
    // End of variables declaration//GEN-END:variables

}