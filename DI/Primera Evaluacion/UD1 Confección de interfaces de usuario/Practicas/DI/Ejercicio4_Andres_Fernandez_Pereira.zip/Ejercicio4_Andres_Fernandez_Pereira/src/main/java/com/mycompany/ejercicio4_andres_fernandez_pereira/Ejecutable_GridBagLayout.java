/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio4_andres_fernandez_pereira;

/**
 *
 * @author andri
 */
public class Ejecutable_GridBagLayout {
    public static void main(String[] args) {
        AndresFernandezPereira_GridBagLayout ejecutable_GridBagLayout = new AndresFernandezPereira_GridBagLayout();
        ejecutable_GridBagLayout.setVisible(true);
    }
    
}
